package com.ecommerce.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingJUnitFourApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingJUnitFourApplication.class, args);
	}

}
