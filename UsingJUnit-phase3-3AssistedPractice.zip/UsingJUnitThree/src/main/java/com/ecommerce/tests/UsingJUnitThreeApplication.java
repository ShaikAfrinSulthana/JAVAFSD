package com.ecommerce.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingJUnitThreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingJUnitThreeApplication.class, args);
	}

}
