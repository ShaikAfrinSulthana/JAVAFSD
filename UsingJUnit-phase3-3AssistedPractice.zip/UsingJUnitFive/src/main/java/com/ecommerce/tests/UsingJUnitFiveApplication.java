package com.ecommerce.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingJUnitFiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingJUnitFiveApplication.class, args);
	}

}
