package com.ecommerce.tests;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsingJUnitFiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
