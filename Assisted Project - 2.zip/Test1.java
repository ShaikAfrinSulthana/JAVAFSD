package assignment;

public class Test1 {
	
	    public static void main(String args[])  
	    { 
	        MountainBike mb = new MountainBike(3, 100, 25); 
	        System.out.println(mb.toString());
	    } 

}
