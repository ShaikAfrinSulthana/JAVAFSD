package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class UserController {
	@Autowired
	UserRepository repo;

public String Check(String username,String password)
{
	User u=new User();
	User uu=new User();
	u.setUsername("admin");
	u.setPassword("adminsuccessful");;
	uu.setUsername(username);
	uu.setPassword(password);
      if(u.equals(uu))
		return "User is Authenticated";

	else
		return "User is not Authenticated";
}
}
