package com.example.demo;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
@RunWith(SpringRunner.class)
@SpringBootTest
public class AuthenticationTests {
	@Autowired
    UserRepository repo;
	UserController user;
	@Before
	public void before() {
		user=new UserController();
		System.out.println("before");
	}
	@Test
	public void test() {
	System.out.println("inside the test");
		User u=new User();
		u.setUsername("admin");
		u.setPassword("adminsuccessful");
		assertNotNull(repo.save(u));
	}
	@Test
	public void test1() {
		assertEquals("User is Authenticated",user.Check("admin","adminsuccessful"));
		System.out.println("inside the test-1");
	}
	@Test
	public void test2() {
		
		assertEquals("User is not Authenticated",user.Check("admin","adminafrin"));
		System.out.println("inside the test-2");
	}
	@After
	public void after() {
		user=null;
		System.out.println("after");
	}
}


